
typedef struct {

 char courseName [64];
 char courseSched [4];
 unsigned int courseHours ;
 unsigned int courseSize ;
 } COURSE ;

